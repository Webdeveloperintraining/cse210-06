class Lives:
    '''
        Keeps track of the players lives
    '''
    
    def __init__(self):
        self._lives = 4
        self._life_icon = '@'
        
    
    def add_life(self, add_amount = 1):
        '''
            adds a specified amount of lives to user, default is one
            
            ARGS:
            add_amount: the number of lives to add, default is one
        '''
        self._lives += add_amount
        
    def remove_life(self):
        '''
            removes a life from the user
        '''
        
        self._lives -= 1
        
    def get_lives(self):
        '''
            returns the amount of lives the user has
        '''
        
        return self._lives
    
    def get_lives_text(self):
        '''
            returns the users life amount in text using the icon
        '''
        text = ''
        for i in range(self._lives):
            text += f' {self._life_icon}'
            
        return str(text)