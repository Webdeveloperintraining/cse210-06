class WordCreator:
    '''
        gets words and handles them
    '''
    
    def __init__(self):
        self._word = 'hello'
        self._word_array = self.split_word()
        self._guessed_underscores = self.mark_underscores()
        
        
    def get_word(self):
        '''
            returns the word
        '''
        return self._word
    
    def get_word_array(self):
        '''
            returns the word array
        '''
        
        return self._word_array
    
    def get_word_length(self):
        '''
            returns the world length
        '''
        
        return len(self._word_array)
    
    def split_word(self):
        '''
            splits the word into the word array
        '''
        
        return [*self._word]
            
    def mark_underscores(self):
        '''
            marks out where the underscores go
        '''
        
        text = []
        for i in range(len(self._word_array)):
            text.append('  _')
            
        return text
            
    
    def get_underscores(self):
        '''
            returns the underscores to be displayed to user
        '''
        
        text = ''
        
        for letter in self._guessed_underscores:
            text += f'  {letter}'
        
        return text
    
    def check_guess(self, letter):
        '''
            checks if the letter passed in is in the word or not
            
            ARGS:
            letter: the letter to be checked
            
            RETURN:
            returns True if it is in the word, False if else
        '''
        in_word = False
        for i in range(len(self._word_array)):
            if self._word_array[i].lower() == letter.lower():
                self._guessed_underscores[i] = self._word_array[i]
                in_word = True
                
        return in_word
                